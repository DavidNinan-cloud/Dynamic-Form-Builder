import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import Divider from '@mui/material/Divider';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import { BlogInfoArray, SideBarList} from './db'
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import CardHeader from '@mui/material/CardHeader';
import { red } from '@mui/material/colors';
import { Box } from '@mui/material';
import ListItemButton from '@mui/material/ListItemButton';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import Collapse from '@mui/material/Collapse';

export default function DearInvestors() {

    const [openArray, setOpenArray] = React.useState([])

    React.useEffect(()=>{
        let arr = [...SideBarList.marketUpdates]
        let indexArray = []
        for (let item of arr){
            indexArray.push(false)

        }
        setOpenArray(indexArray)
    },[SideBarList])

    const handleClick = (index) =>{
        let arr = [...openArray]
        arr[index] = !arr[index]
        setOpenArray(arr)
    }
  return (
    <div className='bg-slate-50 min-h-fit p-2'>
        <div className='w-full py-2'>
            <p className='text-cyan-700 font-bold text-3xl'>Our Latest Updates...</p>
        </div>
        <div className='w-full flex justify-between gap-x-2'>
            <div>
                {
                    BlogInfoArray && BlogInfoArray.map((BlogInfo,BlogInfoIndex)=>{
                        return(
                            <div key={BlogInfoIndex} className='w-full p-6 border my-3 bg-white'>
                                {/* Header */}
                                <div>
                                    <div className='py-3 font-bold sm:text-2xl lg:text-4xl'>
                                        {/* bold header */}
                                        {BlogInfo.head.BoldHeader}
                                    </div>
                                    {/* by info header */}
                                    {
                                        BlogInfo.head.writerImg && (
                                            <div>
                                                {/* <Avatar
                                                    alt="Remy Sharp"
                                                    src={writerImg}
                                                    sx={{ width: 56, height: 56 }}
                                                /> */}
                                                    <CardHeader
                                                            avatar={
                                                            <Avatar alt="Remy Sharp"
                                                                src={BlogInfo.head.writerImg}
                                                                sx={{ width: 56, height: 56 }}
                                                                aria-label="recipe"/>
                                                            }
                                                            // action={
                                                            // <IconButton aria-label="settings">
                                                            //     <MoreVertIcon />
                                                            // </IconButton>
                                                            // }
                                                            title={BlogInfo.head.writerName}
                                                            subheader={BlogInfo.head.blogDate}
                                                        />
                                            </div>
                
                                        )
                                    }
                                    {
                                        BlogInfo.head.mainImg && (
                                        <div className='w-fit border'>
                                            {/* Main Image */}
                                            <img src={BlogInfo.head.mainImg} alt='img' className={`h-[${BlogInfo.head.mainImgHeight}rem] w-[${BlogInfo.head.mainImgWidth}rem]`}/>
                                            {BlogInfo.head.mainImgSource && (<div className='bg-slate-100 text-sm'>Image Source :{BlogInfo.head.mainImgSource}</div>)}
                                        </div>
                                        )
                                    }
                                    
                                </div>
                                {/* Body */}
                                <div>
                                    <div>
                                        {BlogInfo.body.SoftHeader && (
                                        <div className='py-3 text-base lg:text-xl font-medium'>
                                            {/* soft header */}
                                            {BlogInfo.body.SoftHeader}
                                        </div>)}
                                    </div>
                                    
                                        {/* paragraph */}
                                    <div>
                                        {
                                            BlogInfo && BlogInfo.body.paragraphs && BlogInfo.body.paragraphs.map((item,index)=>{
                                                return(
                                                    <p key={index}>
                                                        {item.text}
                                                    </p>
                                                )
                                            }) 
                                            
                                        }
                                    </div>
                                </div>
                                {/* Footer */}
                                <div>
                                    {/* Clarification */}
                                    {   BlogInfo.footer.clarification && (
                                        <p className='text-base italic'>{`Clarification ${BlogInfo.footer.clarificationDate}: ${BlogInfo.footer.clarification}`}</p>
                                    )
                                    }
                                    {/* Related Artical Link */}
                                    {   BlogInfo.footer.relatedArticals && BlogInfo.footer.relatedArticals.length > 0 && (
                                        <div className='flex flex-col my-2'>
                                            <p className='font-bold'>Related Articles :</p>
                                            {BlogInfo.footer.relatedArticals.map((item,index)=>{
                                                return(
                                                    <a key={index} className='text-sm font-semibold underline hover:text-red-600' href=''>{
                                                        item.relatedArticalTitle}
                                                    </a>
                                                )
                                            })}
                                        </div>
                                    )
                                    }
                
                                    {/* Related To Author Link */}
                                    {
                                        BlogInfo.head.writerName && (
                                        <div>    
                                            <a className='text-sm font-semibold underline hover:text-red-600 my-2' href=''>Read More From {BlogInfo.head.writerName}</a>
                                        </div>
                                        )
                                    }
                                    {/* Contact Us   */}
                                    <div className='my-2'>
                                        <a className='text-sm font-semibold underline hover:text-red-600 my-2' href=''>Send us your questions</a>
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>


            
            <div className='w-fit lg:w-[44rem]'>
                <Box sx={{ flexGrow: 1}} className='my-3'>
                {/* Our Type 5 Updates */}
                {SideBarList.topUpdates && (
                    <List sx={{ width: '100%', bgcolor: 'background.paper' }} dense={true}>
                        <ListItem alignItems="flex-start">
                            <ListItemText primary={<p className='text-base font-bold'>Our Top Updates</p>} />
                        </ListItem>
                        {
                            SideBarList.topUpdates && SideBarList.topUpdates.map((item,index)=>{
                                return(
                                    <React.Fragment key={index}>
                                    <Divider variant="inset" component="li" />
                                    <ListItem alignItems="flex-start">
                                        <ListItemText primary={<p className='text-base ml-2'>{item.title}</p>} />
                                    </ListItem>
                                    
                                    </React.Fragment>
                                )
                            })
                        }
                    </List>
                )}

                {/* Market Updates */}
                {SideBarList.marketUpdates && (
                    <List sx={{ width: '100%', bgcolor: 'background.paper' }} dense={true}>
                        <ListItem alignItems="flex-start">
                            <ListItemText primary={<p className='text-base font-bold'>Market Updates</p>} />
                        </ListItem>
                        {
                            SideBarList.marketUpdates && SideBarList.marketUpdates.map((item,index)=>{
                                return(
                                    <React.Fragment key={index}>
                                    <Divider variant="inset" component="li" />
                                    <ListItemButton onClick={()=>{handleClick(index)}}>
                                        <ListItem alignItems="flex-start">
                                            <ListItemText primary={<p className='text-base ml-2 font-medium'>{item.title}</p>} />
                                        </ListItem>
                                        {openArray[index] ? <ExpandLess /> : <ExpandMore />}
                                    </ListItemButton>
                                    <Collapse in={openArray[index]} timeout="auto" unmountOnExit>
                                        {
                                            item.updates && item.updates.map((innerItem,innerIndex)=>{
                                                return(
                                                    <List key={innerIndex} className='pl-4' dense={true} disablePadding>
                                                        <ListItem alignItems="flex-start">
                                                            <ListItemText primary={<p className='text-base ml-2 '>{innerItem.title}</p>} />
                                                        </ListItem>
                                                    </List>
                                                )
                                            })
                                        }
                                    </Collapse>
                                    
                                    </React.Fragment>
                                )
                            })
                        }
                    </List>
                )}

                {/* Our Experts */}
                {SideBarList.ourExperts && (
                    <List sx={{ width: '100%', bgcolor: 'background.paper' }} dense={true}>
                        <ListItem alignItems="flex-start">
                            <ListItemText primary={<p className='text-base font-bold'>Articles By Our Experts</p>} />
                        </ListItem>
                        {
                            SideBarList.ourExperts && SideBarList.ourExperts.map((item,index)=>{
                                return(
                                    <React.Fragment key={index}>
                                    <Divider variant="inset" component="li" />
                                    <ListItem alignItems="flex-start">
                                        <ListItemAvatar>
                                        <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
                                        </ListItemAvatar>
                                        <ListItemText
                                        primary={item.name}
                                        secondary={
                                            <React.Fragment>
                                            <Typography
                                                sx={{ display: 'inline' }}
                                                component="span"
                                                variant="body2"
                                                color="text.primary"
                                            >
                                                {item.head}
                                            </Typography>
                                                {` ${item.subhead}`}
                                            </React.Fragment>
                                        }
                                        />
                                    </ListItem>
                                    
                                    </React.Fragment>
                                )
                            })
                        }
                    </List>
                )}
                </Box>    
            </div>
        </div>
    </div>
  )
}
