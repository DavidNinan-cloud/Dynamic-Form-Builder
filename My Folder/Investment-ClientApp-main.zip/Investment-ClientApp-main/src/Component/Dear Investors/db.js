
import writerImg from './writerIMG.jpg'
import mainImg from './duaLipa.jpg'

export const BlogInfoArray = 
[   
    {
        head:{
            writerImg:writerImg,
            writerName:"David Ninan",
            blogDate:"September 15, 2022",
            mainImg:mainImg,
            mainImgWidth:90,
            mainImgHeight:45,
            mainImgSource:'abc.com',
            BoldHeader : "'Incitement to violence': Musk kicks Kanye West off Twitter after Hakenkreuz post | Explained"

        },
        body:{
            SoftHeader : "Trouble mounted for rapper Kanye West after Elon Musk suspended his Twitter when the former's account showed an image that appeared to show a Hakenkreuz inside a Star of David.",
            paragraphs:[{
                text:'Nord Stream 1, an underwater pipeline running across the Baltic Sea to Germany, had been supplying EU states with 35% of all the gas they imported from Russia.'
            }]
        },
        footer:{
            clarification : "A previous version of this story contained a graphic with the title: 'The UK has much less gas storage than some other European countries'. The aim was to show how much gas the UK had in storage at that time. It was not intended to show the UK's total capacity for gas storage.",
            clarificationDate : "21 October",
            relatedArticals:[{
                relatedArticalTitle : 'Dua Lipa New Album Release',
                relatedArticalTitleId : '',
            },{
                relatedArticalTitle : 'Dua Lipa New Viral Hit',
                relatedArticalTitleId : '',
            }],
            relatedAuthor : '',
            relatedAuthorId : '',
        }
    },{
        head:{
            writerImg:writerImg,
            writerName:"David Ninan",
            blogDate:"September 15, 2022",
            mainImg:mainImg,
            mainImgWidth:90,
            mainImgHeight:45,
            mainImgSource:'abc.com',
            BoldHeader : "'Incitement to violence': Musk kicks Kanye West off Twitter after Hakenkreuz post | Explained"

        },
        body:{
            SoftHeader : "Trouble mounted for rapper Kanye West after Elon Musk suspended his Twitter when the former's account showed an image that appeared to show a Hakenkreuz inside a Star of David.",
            paragraphs:[{
                text:'Nord Stream 1, an underwater pipeline running across the Baltic Sea to Germany, had been supplying EU states with 35% of all the gas they imported from Russia.'
            }]
        },
        footer:{
            clarification : "A previous version of this story contained a graphic with the title: 'The UK has much less gas storage than some other European countries'. The aim was to show how much gas the UK had in storage at that time. It was not intended to show the UK's total capacity for gas storage.",
            clarificationDate : "21 October",
            relatedArticals:[{
                relatedArticalTitle : 'Dua Lipa New Album Release',
                relatedArticalTitleId : '',
            },{
                relatedArticalTitle : 'Dua Lipa New Viral Hit',
                relatedArticalTitleId : '',
            }],
            relatedAuthor : '',
            relatedAuthorId : '',
        }
    }
]

export const SideBarList = {
    topUpdates : [{
            title:'Himalyan Mountain Trek Is A Must Do Task',
            storyId:0
        },{
            title:'Himalyan Mountain Trek Is A Must Do Task',
            storyId:0
        },{
            title:'Himalyan Mountain Trek Is A Must Do Task',
            storyId:0
        }],
    marketUpdates : [
        {
            title:"Supply & Demand",
            updates:[{
                title:'Himalyan Mountain Trek Is A Must Do Task',
                storyId:0
            },{
                title:'Himalyan Mountain Trek Is A Must Do Task',
                storyId:0
            }]
        },{
            title:"News Related Our Companies",
            updates:[{
                title:'Himalyan Mountain Trek Is A Must Do Task',
                storyId:0
            },{
                title:'Himalyan Mountain Trek Is A Must Do Task',
                storyId:0
            }]
        },{
            title:"Latest New",
            updates:[{
                title:'Himalyan Mountain Trek Is A Must Do Task',
                storyId:0
            },{
                title:'Himalyan Mountain Trek Is A Must Do Task',
                storyId:0
            }]
        }],
    ourExperts : [{
            name:"David Ninan",
            head:"XYZ",
            subhead:"123"
            
        },{
            name:"Ruth Hegade",
            head:"XYZ",
            subhead:"123"
            
        },{
            name:"Aman Shinde",
            head:"XYZ",
            subhead:"123"
            
        }
    ]
}
