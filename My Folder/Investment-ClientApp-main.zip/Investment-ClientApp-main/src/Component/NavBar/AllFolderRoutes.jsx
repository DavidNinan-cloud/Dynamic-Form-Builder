import React from 'react'
import { BrowserRouter as Router, Route, Link, Routes, NavLink, useLocation} from "react-router-dom";
import Dashboard from '../../Component/Dashboard/Dashboard';
import PortFolio from '../../Component/PortFolio/PortFolio';
import DearInvestors from '../Dear Investors/DearInvestors';
import NavBar from './NavBar';

export default function AllFolderRoutes() {
    let location = useLocation();
    const NotFound = () => (  <h1>404.. This page is not found! - {location.pathname}</h1>)
  
  return (
    <>
    {/* Navbar */}
    <NavBar/>

    {/* ROUTES */}
    <div className='\'>

        <Routes>
            <Route  path='/' element={<Dashboard/>}/>
            <Route  path='/portfolio' element={<PortFolio/>}/>
            <Route path='/dear-investor' element={<DearInvestors/>}/>

            {/* <Route path='EMR' element={<EMR/>}>
                <Route path='Complaints' element={<EMRComponents/>}/>
                <Route path='EMRpage' element={<EMRpage/>}/>
            </Route> */}
            <Route path='*' component={NotFound} />
        </Routes>
    </div>
      
    </>
  )
}
