import React from 'react'
// import { BrowserRouter as Router, Route, Link, Routes, NavLink, useLocation} from "react-router-dom";

import NavScroll from './NavScroll'

// const headContents = [
//   {
//     id:1,
//     head:"Home",
//     subMenus:[
//       {
//         subid:1,
//         subHead:"Home 1"
//       },
//       {
//         subid:2,
//         subHead:"Home 2"
//       },
//       {
//         subid:3,
//         subHead:"Home 3"
//       },
//       {
//         subid:4,
//         subHead:"Home 4"
//       },
//       {
//         subid:5,
//         subHead:"Home 5"
//       },
      
//     ],
//     expand:false,
//   },  
//   {
//     id:2,
//     head:"About",
//   },  
//   {
//     id:3,
//     head:"Services",
//     subMenus:[
//       {
//         subid:1,
//         subHead:"Services"
//       },
//       {
//         subid:2,
//         subHead:"Services Details"
//       },
      
      
//     ],
//     expand:false,
//   },  
//   {
//     id:4,
//     head:"Pages",
//     subMenus:[
//       {
//         subid:1,
//         subHead:"About"
//       },
//       {
//         subid:2,
//         subHead:"Team"
//       },
//       {
//         subid:3,
//         subHead:"Projects",
//         subSubMenu:[
//           {
//             subSubId:1,
//             subSubName:"Projects",
//           },
//           {
//             subSubId:2,
//             subSubName:"Projects Details",
//           },
          
//         ],
//         sExpand:false,
//       },
//       {
//         subid:4,
//         subHead:"FAQ"
//       },
//       {
//         subid:5,
//         subHead:"Appointment"
//       },
//       {
//         subid:6,
//         subHead:"Testimonial"
//       },
//       {
//         subid:7,
//         subHead:"How It Works"
//       },
//       {
//         subid:8,
//         subHead:"Solution",
//         subSubMenu:[
//           {
//             subSubId:1,
//             subSubName:"Solutions",
//           },
//           {
//             subSubId:2,
//             subSubName:"Solutions Details",
//           },
          
//         ],
//         sExpand:false,
//       },
//       {
//         subid:9,
//         subHead:"Shop",
//         subSubMenu:[
//           {
//             subSubId:1,
//             subSubName:"Shop",
//           },
//           {
//             subSubId:2,
//             subSubName:"Cart",
//           },
//           {
//             subSubId:3,
//             subSubName:"Checkout",
//           },
//           {
//             subSubId:4,
//             subSubName:"Products Details",
//           },
          
//         ],
//         sExpand:false,
//       },
//       {
//         subid:10,
//         subHead:"User",
//         subSubMenu:[
//           {
//             subSubId:1,
//             subSubName:"Sign In",
//           },
//           {
//             subSubId:2,
//             subSubName:"Sign Up",
//           },
//         ],
//         sExpand:false,
//       },
//       {
//         subid:11,
//         subHead:"Terms & Conditions"
//       },
//       {
//         subid:12,
//         subHead:"Privacy Policy"
//       },
//       {
//         subid:13,
//         subHead:"404 Error"
//       },
//       {
//         subid:14,
//         subHead:"Contact"
//       },
//     ],
//     expand:false,
//   },
//   {
//     id:5,
//     head:"Blog",
//     subMenus:[
//       {
//         subid:1,
//         subHead:"Blog Grid"
//       },
//       {
//         subid:2,
//         subHead:"Blog Right Sidebar"
//       },
//       {
//         subid:3,
//         subHead:"Blog Details"
//       },
      
//     ],
//     expand:false,
//   },
//   {
//     id:6,
//     head:"Contact",
//   },
// ];

const headContents = [
  {
    id:1,
    head:"Home",
    routerLink:'/'
  }, 
  {
    id:2,
    head:"Dashboard",
    routerLink:'/'
  },  
  {
    id:2,
    head:"Portfolio",
    routerLink:'/portfolio'
  },  
  {
    id:3,
    head:"Dear Investors",
    routerLink:'/dear-investor'
  },  
  {
    id:4,
    head:"Trade Book",
    routerLink:'/trade-book'
  },
  {
    id:5,
    head:"About",
    routerLink:'/about'
  },
  {
    id:6,
    head:"Contact",
    routerLink:'/contact'
  },
];
export default function NavBar() {
  return (
    <div>
        <NavScroll headContents={headContents}/>
    </div>
  )
}
