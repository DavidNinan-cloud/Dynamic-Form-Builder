import React from 'react'
import MdWhatifUInvest from './IFYou-Invest/MdWhatifUInvest';
import LgWhatifUInvest from './IFYou-Invest/LgWhatifUInvest';
import FundOverView from './IFYou-Invest/FundOverView';



// import { BiRupee } from "react-icons/bi";
// import { BsBorderWidth } from 'react-icons/bs';


function IfYouInvested() {
  return (
    <>  
<MdWhatifUInvest/>
      <div className='bg-gray-100 py-8  md:flex md:gap-10 '>
        <LgWhatifUInvest/>
         <FundOverView/>
      </div>
    </>
  )
}

export default IfYouInvested
