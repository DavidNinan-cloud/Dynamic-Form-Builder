import React from 'react'
import { AiFillFacebook,AiOutlineTwitter,AiOutlineCopyright } from "react-icons/ai";
import { BsInstagram,BsLinkedin } from "react-icons/bs";

import {MdEmail } from "react-icons/md";




function Footer() {
  return (
    <>
 <div className='bg-gray-700 text-center mt-5'>
  
        </div>
      <div className='bg-black md:flex md:justify-between md:py-5 py-3'>
       
        <div className='md:mx-10'>
        <div className='flex gap-6 mx-5 md:mx-8 my-5'>
          <div className='flex md:flex-col '>
          <img src='https://www.google.com/url?sa=i&url=https%3A%2F%2Fstock.adobe.com%2Fsearch%3Fk%3Dinvest%2Blogo&psig=AOvVaw0jHpT-chAMT4XVKKcMI5bE&ust=1669444678294000&source=images&cd=vfe&ved=0CBAQjRxqFwoTCPjbzZncyPsCFQAAAAAdAAAAABAQ'/>
    <h1 className='text-3xl  text-white font-extrabold'>Logo</h1>
          </div>
<p className='text-sm md:text-lg text-gray-200 px-5 md:px-10'>The passage experienced <br/> a surge  in popularity during <br/> the 1960s when Letraset.
    </p>
        </div>
        <div className='flex items-center justify-center md:justify-start gap-6 md:gap-10 my-4 md:my-6 mx-10 md:mx-10'>
<AiFillFacebook className='text-gray-500 text-3xl'/>
<BsInstagram className='text-gray-500 text-2xl'/>
<AiOutlineTwitter className='text-gray-500 text-3xl'/>
<BsLinkedin className='text-gray-500 text-2xl'/>
<MdEmail className='text-gray-500 text-3xl'/>
    </div>
        </div>
        <div className='flex justify-between text-green-800 md:mx10 mx-10 md:gap-40  '>
      <div>
        <h1 className='text-white font-semibold'>
          More Biyn
        </h1>
        <p>Media</p>
        <p>Event</p>
        <p>Program</p>
        <p>Spaces</p>
        <p>Newsletter</p>
        <p>Deals</p>
      </div>
      <div>
        <h1 className='text-white font-semibold'>
          About Biyn
        </h1>
        <p>Paartner with us </p>
        <p>Companies</p>
        <p>Terms & Condition</p>
        <p>Cookies Statement</p>
        <p>Privacy Statement</p>
        <p>Editorial Policy</p>
      </div>
      <div className='hidden lg:block'>
        <h1 className='text-white font-semibold'>
          More Biyn
        </h1>
        <p>Media</p>
        <p>Event</p>
        <p>Program</p>
        <p>Spaces</p>
        <p>Newsletter</p>
        <p>Deals</p>
      </div>
      <div className='hidden lg:block'>
        <h1 className='text-white font-semibold'>
          About Biyn
        </h1>
        <p>Paartner with us </p>
        <p>Companies</p>
        <p>Terms & Condition</p>
        <p>Cookies Statement</p>
        <p>Privacy Statement</p>
        <p>Editorial Policy</p>
      </div>
    </div>
      </div>
      <div className='bg-black border-t-2 border-green-800 text-gray-200 py-4 text-center md:text-lg text-sm'>
<h1 className='text-gray-300 '>BIYN is an Investment Company.</h1>
<h1 className='flex items-center justify-center text-gray-300 '>Copyright <AiOutlineCopyright/> 2022 All Rights Reserved By BIYN </h1>
      </div>
    </>
  )
}

export default Footer
