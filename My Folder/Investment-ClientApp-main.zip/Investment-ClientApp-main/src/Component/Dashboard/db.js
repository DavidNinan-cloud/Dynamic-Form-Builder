export const indexFundDetails= {
        Nav:124.7,
        D:113.5,
        percentage:1.8
    }


export const performanceDetails={
    Invested:6000,
    CurrentValue:6500,
    Gain:484.1,
    XIRR:14.2
}

export const performanceGraph=[
    {
        name: '07-05-2021',
        uv: '0',
        pv: 2400,
        amt: 2400,
      },
      {
        name: 'Page B',
        uv: 3000,
        pv: 1398,
        amt: 2210,
      },
      {
        name: 'Page C',
        uv: 2000,
        pv: 9800,
        amt: 2290,
      },
      {
        name: 'Page D',
        uv: 2780,
        pv: 3908,
        amt: 2000,
      },
      {
        name: 'Page E',
        uv: 1890,
        pv: 4800,
        amt: 2181,
      },
      {
        name: 'Page F',
        uv: 2390,
        pv: 3800,
        amt: 2500,
      },
      {
        name: 'Page G',
        uv: 3490,
        pv: 4300,
        amt: 2100,
      },
      {
        name: 'Page A',
        uv: 4000,
        pv: 2400,
        amt: 2400,
      },
      {
        name: 'Page B',
        uv: 3000,
        pv: 1398,
        amt: 2210,
      },
      {
        name: 'Page C',
        uv: 2000,
        pv: 9800,
        amt: 2290,
      },
      {
        name: 'Page D',
        uv: 2780,
        pv: 3908,
        amt: 2000,
      },
      {
        name: 'Page E',
        uv: 1890,
        pv: 4800,
        amt: 2181,
      },
      {
        name: 'Page F',
        uv: 2390,
        pv: 3800,
        amt: 2500,
      },
      {
        name: 'Page G',
        uv: 3490,
        pv: 4300,
        amt: 2100,
      },{
        name: 'Page A',
        uv: 4000,
        pv: 2400,
        amt: 2400,
      },
      {
        name: 'Page B',
        uv: 3000,
        pv: 1398,
        amt: 2210,
      },
      {
        name: 'Page C',
        uv: 2000,
        pv: 9800,
        amt: 2290,
      },
      {
        name: 'Page D',
        uv: 2780,
        pv: 3908,
        amt: 2000,
      },
      {
        name: 'Page E',
        uv: 1890,
        pv: 4800,
        amt: 2181,
      },
      {
        name: 'Page F',
        uv: 2390,
        pv: 3800,
        amt: 2500,
      },
      {
        name: 'Page G',
        uv: 3490,
        pv: 4300,
        amt: 2100,
      },{
        name: 'Page A',
        uv: 4000,
        pv: 2400,
        amt: 2400,
      },
      {
        name: 'Page B',
        uv: 3000,
        pv: 1398,
        amt: 2210,
      },
      {
        name: 'Page C',
        uv: 2000,
        pv: 9800,
        amt: 2290,
      },
      {
        name: 'Page D',
        uv: 2780,
        pv: 3908,
        amt: 2000,
      },
      {
        name: 'Page E',
        uv: 1890,
        pv: 4800,
        amt: 2181,
      },
      {
        name: 'Page F',
        uv: 2390,
        pv: 3800,
        amt: 2500,
      },
      {
        name: 'Page G',
        uv: 3490,
        pv: 4300,
        amt: 2100,
      },
      {
        name: 'Page G',
        uv: 3090,
        pv: 4000,
        amt: 2100,
      },
]

export const redeemedToday={
  Gains:468.9,
  ShortTerm:468.9,
  LongTerm:0,
  TotalTax:70.3,
  STCGTax:70.3,
  LTCG:0,
  PostTax:398.6,
  Current:6.5,
  ExitLoad:0,
  ExpensesPaid:10.8,
  Commissions:0
}

export const ifInvestedBarGraph=[
    {
        name: 'Saving a/c',
        uv: 4000,
        pv: 2400,
        amt:'40.92K'
      },
      {
        name: 'Regular plan (upto 1% Commission)',
        uv: 3500,
        pv: 5398,
        amt:'45.50k'
      },
      {
        name: 'Direct plan on INDmoney (0% commission)',
        uv: 2000,
        pv: 9800,
        amt:'46.26k'
      },
]

export const ifYouInvestedDetails={
    FundPastReturns:51300,
    Profit:28.5
}

export const fundOverView={
    ExpenseRatio:0.2,
    Benchmark:'IIS Nifty 50 TR INR',
    AUM:8941,
    InceptionDate:'1 January, 2013',
    MinLumpsum:5000,
    SIP:500,
    ExitLoad:0,
    LockIn:"No Lock In",
    TurnOver:6.34
}