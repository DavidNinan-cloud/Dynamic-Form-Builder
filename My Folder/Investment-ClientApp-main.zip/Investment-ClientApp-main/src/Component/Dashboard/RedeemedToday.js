import React, { useContext, useEffect,useState } from 'react'
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { BiRupee } from "react-icons/bi";
import { FaSquareFull } from "react-icons/fa";
import { AiOutlineInfoCircle } from "react-icons/ai";
import { ElementsContext } from './DashboardContextApi';





function RedeemedToday(){
  const {redeemedToday}=useContext(ElementsContext)

const [redeemedTd,setRedeemedTd]=useState(null)

useEffect(()=>{
  setRedeemedTd(redeemedToday)
},[redeemedToday])



    return(
        <>
        <div className='bg-white lg:hidden sm:block'>
            <div>
                
                <div className='bg-white px-4 pt-3 '>
                    <p className='font-semibold'>What if I Redeemed Today?</p>
                    <div className='mt-3'>
                    <p className='rounded bg-blue-200 text-blue-700 p-1 bg-opacity-40 w-20 text-center'>
                      Today</p>
                    </div>
                    
                </div >
               
                <div className='pt-4'>
 {/* Accordion */}
 <div className='shadow-2xl'>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography sx={{fontWeight:'600'}}>Gains & Taxes</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            
            <div className='flex justify-between mx-5 font-semibold text-sm'>
              {/* gain */}
              <p>Gains</p>
              <p className='flex items-center'><BiRupee/>{redeemedTd ? redeemedTd.Gains : ""}</p>
            </div>
            <div className='flex justify-between mx-5 text-gray-400  text-sm leading-8 '>
              <p>Short Term Gains</p>
              <p className='flex items-center'><BiRupee/>{redeemedTd ? redeemedTd.ShortTerm : ""}</p>
            </div>
            <div className='flex justify-between mx-5 text-gray-400  text-sm leading-8 '>
              <p>Long Term Gains</p>
              <p className='flex items-center'><BiRupee/> {redeemedTd ? redeemedTd.LongTerm : ""}</p>
            </div>

            {/* Taxes */}

            <div className='flex justify-between mx- font-semibold text-sm mt-2'>
            <p className='flex items-center gap-2 '> <FaSquareFull className="text-gray-300 text-sm"/> 
            Total Taxes</p>
              <p className='flex items-center pr-5'><BiRupee/> {redeemedTd ? redeemedTd.TotalTax : ""}</p>
            </div>
            <div className='flex justify-between mx-5 text-gray-400  text-sm leading-8 '>
              <p>STCG Tax</p>
              <p className='flex items-center'><BiRupee/> {redeemedTd ? redeemedTd.STCGTax : ""}</p>
            </div>
            <div className='flex justify-between mx-5 text-gray-400  text-sm leading-8 '>
              <p>LTCG Tax</p>
              <p className='flex items-center'><BiRupee/> {redeemedTd ? redeemedTd.LTCGTax : ""}</p>
              </div>

              {/* Post */}
              <div className='flex justify-between mx- font-semibold text-sm text-green-600 mt-2'>
            <p className='flex items-center gap-2 '> <FaSquareFull className="text-green-600 text-sm"/>
             Post Tax Gains</p>
              <p className='flex items-center pr-5'><BiRupee/> {redeemedTd ? redeemedTd.PostTax : ""}</p>
            </div>

          </Typography>
        </AccordionDetails>
      </Accordion>

{/* Exit Load */}
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography sx={{fontWeight:'600'}}>
              Exit Load
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
           
          <div className='flex justify-between text-gray-600  font-semibold text-sm '>
            <p className='flex items-center gap-2 '> <FaSquareFull className="text-blue-700 text-sm"/> 
            Current</p>
              <p className='flex items-center pr-5'><BiRupee/> {redeemedTd ? redeemedTd.Current : ""}</p>
            </div>

           <div className='flex justify-between text-gray-600  font-semibold text-sm mt-2'>
            <p className='flex items-center gap-2 '> <FaSquareFull className="text-gray-300 text-sm"/> 
            Exit Load <AiOutlineInfoCircle className='text-gray-600 text-lg font-semibold'/> </p>
              <p className='flex items-center pr-5'><BiRupee/> {redeemedTd ? redeemedTd.ExitLoad : ""}</p>
            </div>

          </Typography>




        </AccordionDetails>
      </Accordion>

{/* Expenses & Commission */}
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography sx={{fontWeight:'600'}}>
              Expenses & Commission
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
           
          <div className='flex justify-between text-gray-600  font-semibold text-sm '>
            <p className='flex items-center gap-2 '> <FaSquareFull className="text-yellow-500 text-sm"/> 
            Expenses Paid</p>
              <p className='flex items-center pr-5'><BiRupee/> {redeemedTd ? redeemedTd.ExpensesPaid : ""}</p>
            </div>

           <div className='flex justify-between text-gray-600  font-semibold text-sm mt-2'>
            <p className='flex items-center gap-2 '> <FaSquareFull className="text-gray-300 text-sm"/> 
            Commission (if any)<AiOutlineInfoCircle className='text-gray-600 text-lg font-semibold'/> </p>
              <p className='flex items-center pr-5'><BiRupee/> {redeemedTd ? redeemedTd.Commissionsy : ""}</p>
            </div>

          </Typography>




        </AccordionDetails>
      </Accordion>

    </div>
                </div>
            </div>
        </div>
        </>
    )
}

export default RedeemedToday