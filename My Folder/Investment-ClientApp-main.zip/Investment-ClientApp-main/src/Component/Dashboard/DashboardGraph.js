import React, { useContext, useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ElementsContext } from './DashboardContextApi';



function DashboardGraph() {

const {performanceGraph} = useContext(ElementsContext)
const [data,setData] = useState([])
useEffect(()=>{
  setData(performanceGraph)
},[performanceGraph])
  return (
    
    <ResponsiveContainer width="100%" height={300}
    //  aspect={2}
     className="my-8 " >
        <AreaChart
          width={500}
          height={400}
          data={data}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal="" vertical="" />
          <XAxis dataKey="name" />
          <YAxis type='number' domain={['dataMin', 'dataMax']}/>
          <Tooltip />
          {/* <Area type="monotone" dataKey="uv" stackId="1" stroke="#8884d8" fill="#8884d8" /> */}
          <Area type="monotone" dataKey="pv" stackId="1" stroke="##ffc578" fill="##ffc578" />
          <Area type="monotone" dataKey="amt" stackId="1" stroke="#ffc658" fill="#ffc658" />
        </AreaChart>
      </ResponsiveContainer>  
    
  )
}

export default DashboardGraph