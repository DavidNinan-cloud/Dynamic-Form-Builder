
import React,{ useContext, useEffect,useState } from 'react'
import {Button,ButtonGroup,CardContent,TextField,Card} from '@mui/material'
import { BiRupee } from "react-icons/bi";
import { BarChart, Bar, LabelList, XAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { ElementsContext } from '../DashboardContextApi';

function LgWhatifUInvest() {

    const {ifYouInvestedDetails} = useContext(ElementsContext)
  const {ifInvestedBarGraph} = useContext(ElementsContext)

  const [data,setData] = useState([])
  const [fundReturns,setFundReturns]=useState(null)

  useEffect(()=>{
    setData(ifInvestedBarGraph)
    setFundReturns(ifYouInvestedDetails)
  },[ifYouInvestedDetails,ifInvestedBarGraph])

  const [isOneTime,setIsOneTime]=React.useState(true)
    const [years,setYears]=React.useState(0)

    const onClickFunc = () => {
      setIsOneTime(!isOneTime)
    }

  return (
    <div>
      <div className='w-full hidden md:block '>
      <Card sx={{ minWidth: 900,marginX:'40px',boxShadow:'1rem' }}>
        <CardContent>
        <div className='bg-white   '>
        <div className='flex py-4 justify-between md:justify-between md:gap-20 mx-4 md:mx-5'>
            <h1 className='font-semibold md:font-bold md:text-xl'>What if you invested</h1>
            {/* toggle button */}
            <ButtonGroup  aria-label="outlined primary button group" size="small" 
            >
                        <Button variant={isOneTime ? 'outlined':"contained"} onClick={onClickFunc}  size="small" sx={{width:{md:'10rem'},height:{md:'40px'}}}>1-time</Button>
                        <Button variant={!isOneTime ? 'outlined':"contained"} onClick={onClickFunc} size="small" sx={{width:{md:'10rem'},height:{md:'40px'}}}>Monthly SIP</Button>
            </ButtonGroup>
                            
        </div>
        <div className='flex  md:mx-4 justify-center md:justify-start gap-5 md:gap-16 my-2'>
        <TextField id="outlined-basic" label=""   size='small' className='bg-gray-100 w-48 md:w-96 border-none' />
        <Button variant="contained" size='small' className='bg-blue-400 rounded-full w-32'>Update</Button>
        </div>

        <div className='flex justify-between items-center mx-3 my-3 text-lg mt-4 font-semibold' >
          <h1>This Fund's past returns</h1>
          <h1 className='flex items-center text-green-600 mr-10'> <BiRupee/> {fundReturns ? fundReturns.FundPastReturns :""}</h1>
        </div>

        <div className='flex items-center text-lg text-gray-400 justify-between mx-3' >
          <h1 >Profit % (Absolute Return,based on past data)</h1>
          <h1 className='text-black font-semibold mr-10' >{fundReturns ? fundReturns.Profit :""}%</h1>
        </div>

        {/* bar graph */}
        <div className='pl-12' 
        >
        <ResponsiveContainer width="90%" height={200}>
        <BarChart
        
          width={400}
          height={300}
          data={data}
         
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
            
          }}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal="" vertical="" />
          <XAxis dataKey="name" dy={2}  style={{
        fontSize: '12px',
        fontFamily: 'Times New Roman',
    }}  />
          <Bar dataKey="pv" stackId="a" fill="gray" barSize={50}   />
          <Bar dataKey="uv" stackId="a" fill="green" barSize={50} />
          <Bar  stackId="a" fill="black"  className='text-sm font-semibold'>
          <LabelList dataKey="amt" position="top" />
          </Bar>
        
        </BarChart>
      </ResponsiveContainer>
      </div>

      <div className='flex justify-center  pt-4'>
      <ButtonGroup  aria-label="outlined primary button group" size="small" 
            >
              <Button variant={years==0 ? 'contained':"outlined"} 
              onClick={()=>{
                if(years!==0){
                  setYears(0)
                }
                }}  size="small" sx={{width:{md:'10rem'},height:{md:'40px'},width:'7rem'}}>1Y</Button>
              <Button variant={years==1 ? 'contained':'outlined'} 
              onClick={()=>{
                if(years!==1){
                  setYears(1)
                }else{
                  setYears(0)
                }
                }}  size="small" sx={{width:{md:'10rem'},height:{md:'40px'},width:'7rem'}}>3Y</Button>
              <Button variant={years==2 ? 'contained':'outlined'}
               onClick={()=>{
                if(years!==2){
                  setYears(2)
                }else{
                  setYears(0)
                }
                }}
                size="small" sx={{width:{md:'10rem'},height:{md:'40px'},width:'7rem'}}>5Y</Button>
            </ButtonGroup>
      </div>
      </div>
        </CardContent>
      </Card>
      </div>
    </div>
  )
}

export default LgWhatifUInvest
