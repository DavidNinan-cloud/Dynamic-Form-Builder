
import React,{ useContext, useEffect,useState } from 'react'
import {Button,ButtonGroup,TextField,Card} from '@mui/material'
import { BiRupee } from "react-icons/bi";
import { BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, LabelList, ResponsiveContainer } from 'recharts';
import { ElementsContext } from '../DashboardContextApi';

function MdWhatifUInvest() { 

  const {ifYouInvestedDetails} = useContext(ElementsContext)
  const {ifInvestedBarGraph} = useContext(ElementsContext)

  const [data,setData] = useState([])
  const [fundReturns,setFundReturns]=useState(null)

  useEffect(()=>{
    setData(ifInvestedBarGraph)
    setFundReturns(ifYouInvestedDetails)
  },[ifYouInvestedDetails,ifInvestedBarGraph])

  const [isOneTime,setIsOneTime]=React.useState(true)
    const [years,setYears]=React.useState(0)

    const onClickFunc = () => {
      setIsOneTime(!isOneTime)
    }
  return (
    <>
       {/* card 1 */}
       <div className='bg-white block md:hidden'>
        <div className='flex py-4 justify-between md:justify-bwtween md:gap-40 mx-4 md:mx-20'>
            <h1 className='font-semibold md:font-bold md:text-3xl'>What if you invested</h1>
            
            <ButtonGroup  aria-label="outlined primary button group" size="small" 
            >
                        <Button variant={isOneTime ? 'outlined':"contained"} onClick={onClickFunc}  size="small" sx={{width:{md:'10rem'},height:{md:'50px'}}}>1-time</Button>
                        <Button variant={!isOneTime ? 'outlined':"contained"} onClick={onClickFunc} size="small" sx={{width:{md:'10rem'},height:{md:'50px'}}}>Monthly SIP</Button>
            </ButtonGroup>
                            
        </div>
        <div className='flex  md:mx-14 justify-center gap-5 md:gap-10 my-2'>
        <TextField id="outlined-basic" label=""   size='small' className='bg-gray-100 w-48 md:w-80 border-none' />
        <Button variant="contained" size='small' className='bg-blue-400 rounded-full'>Update</Button>
        </div>

        <div className='flex justify-between items-center mx-3 my-3 text-sm mt-4 font-semibold' >
          <h1>This Fund's past returns</h1>
          <h1 className='flex items-center text-green-600'> <BiRupee/> {fundReturns ? fundReturns.FundPastReturns :""}</h1>
        </div>

        <div className='flex items-center text-xs text-gray-400 justify-between mx-3' >
          <h1 >Profit % (Absolute Return,based on past data)</h1>
          <h1 className='text-black font-semibold' >{fundReturns ? fundReturns.Profit :""}%</h1>
        </div>

        {/* bar graph */}
        <div className='pl-6' 
        >
        <ResponsiveContainer width="100%" height={200}>
        <BarChart
        
          width={400}
          height={300}
          data={data}
         
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
            
          }}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal="" vertical="" />
          <XAxis dataKey="name" dy={2}  style={{
        fontSize: '10px',
        fontFamily: 'Times New Roman',
    }}  />
          <Bar dataKey="pv" stackId="a" fill="gray" barSize={40}   />
          <Bar dataKey="uv" stackId="a" fill="green" barSize={40} />
          <Bar  stackId="a" fill="black"  className='text-xs font-semibold'>
          <LabelList dataKey="amt" position="top" />
          </Bar>
        
        </BarChart>
      </ResponsiveContainer>
      </div>

      <div className='flex justify-center '>
      <ButtonGroup  aria-label="outlined primary button group" size="small" 
            >
              <Button variant={years==0 ? 'contained':"outlined"} 
              onClick={()=>{
                if(years!==0){
                  setYears(0)
                }
                }}  size="small" sx={{width:{md:'10rem'},height:{md:'50px'},width:'7rem'}}>1Y</Button>
              <Button variant={years==1 ? 'contained':'outlined'} 
              onClick={()=>{
                if(years!==1){
                  setYears(1)
                }else{
                  setYears(0)
                }
                }}  size="small" sx={{width:{md:'10rem'},height:{md:'50px'},width:'7rem'}}>3Y</Button>
              <Button variant={years==2 ? 'contained':'outlined'}
               onClick={()=>{
                if(years!==2){
                  setYears(2)
                }else{
                  setYears(0)
                }
                }}
                size="small" sx={{width:{md:'10rem'},height:{md:'50px'},width:'7rem'}}>5Y</Button>
            </ButtonGroup>
      </div>
      </div>
    </>
  )
}

export default MdWhatifUInvest
