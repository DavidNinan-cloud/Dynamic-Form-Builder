import React,{ useContext, useEffect,useState } from 'react'
import {CardContent,Card} from '@mui/material'
import { BiRupee } from "react-icons/bi";
import { CgLoadbarSound } from "react-icons/cg";
import { AiOutlineInfoCircle,AiOutlinePieChart,AiOutlineClockCircle,AiOutlineLock } from "react-icons/ai";
import { VscGraphLine } from "react-icons/vsc";
import { HiOutlineCurrencyRupee } from "react-icons/hi";
import { GiCycle } from "react-icons/gi";
import { ElementsContext } from '../DashboardContextApi';

function FundOverView() {
        const {fundOverView} = useContext(ElementsContext)
      const [overView,setOverView]=useState(null)
      
      useEffect(()=>{
        setOverView(fundOverView)
      },[fundOverView])
      
 

  return (
    <>
      
<div className='w-full mr-6'>
  {/* fund Overview */}
      <Card  sx={{ minWidth:100 }}>
        <CardContent>
<h1 className='font-semibold md:font-bold'>Fund Overview</h1>
{/* Expense ratio */}
<div className='flex justify-between mx-2 md:mx-4 mt-1 md:mt-3 text-gray-500 border-b-2 pb-2 py-1 md:py-3'>
  <div className='flex items-center gap-4 font-semibold text-sm '>
    <CgLoadbarSound className='md:text-3xl text-2xl text-blue-700'/>
    <h1 className=''>Expense ratio</h1>
  </div>
  <p className='text-sm'>{overView ? overView.ExpenseRatio : ""}%</p>
</div>
{/* Benchmark */}
<div className='flex justify-between mx-2 md:mx-4 mt-1 md:mt-1 text-gray-500 border-b-2 pb-2 py-1 md:py-3'>
  <div className='flex items-center gap-4 px-2 font-semibold text-sm '>
    <VscGraphLine className='md:text-xl text-lg text-blue-700'/>
    <h1 className=''>Benchmark </h1>
    <AiOutlineInfoCircle className='text-gray-600  text-sm md:text-lg font-semibold'/>
  </div>
  <p className='text-sm'>{overView ? overView.Benchmark : ""}</p>
</div>
{/* AUM */}
<div className='flex justify-between mx-2 md:mx-4 mt-1 md:mt-1 text-gray-500 border-b-2 pb-2 py-1 md:py-3'>
  <div className='flex items-center gap-4 px-1 font-semibold text-sm '>
    <AiOutlinePieChart className='text-xl md:text-2xl text-blue-700'/>
    <h1 className=''>AUM </h1>
  </div>
  <p className='text-sm flex items-center'> <BiRupee/>{overView ? overView.AUM : ""} Cr</p>
</div>
{/* Inception Data */}
<div className='flex justify-between mx-2 md:mx-4 mt-1 md:mt-1 text-gray-500 border-b-2 pb-2 py-1 md:py-3'>
  <div className='flex items-center gap-4 px-1 font-semibold text-sm '>
    <AiOutlineClockCircle className='text-xl md:text-2xl text-blue-700'/>
    <h1 className=''>Inception Date </h1>
  </div>
  <p className='text-sm'>{overView ? overView.InceptionDate : ""}</p>
</div>
{/* Min SIP */}
<div className='flex justify-between mx-2 md:mx-4 mt-1 md:mt-1 text-gray-500 border-b-2 pb-2 py-1 md:py-3'>
  <div className='flex items-center gap-4 px-1 font-semibold text-sm '>
    <HiOutlineCurrencyRupee className=' text-xl md:text-2xl text-blue-700'/>
    <h1 className=''>Min Lumpsum/SIP </h1>
  </div>
  <p className='text-sm flex items-center'><BiRupee/>{overView ? overView.MinLumpsum : ""}/<BiRupee/>{overView ? overView.SIP : ""}</p>
</div>
{/* Exit Load */}
<div className='flex justify-between mx-2 md:mx-4 mt-1 md:mt-1 text-gray-500 border-b-2 pb-2 py-1 md:py-3'>
  <div className='flex items-center gap-4 px-1 font-semibold text-sm '>
    <HiOutlineCurrencyRupee className='text-xl md:text-2xl text-blue-700'/>
    <h1 className=''>Exit Load </h1>
  </div>
  <p className='text-sm flex items-center'>{overView ? overView.ExitLoad : ""}%</p>
</div>
{/* Lock in */}
<div className='flex justify-between mx-1 md:mx-4 mt-1 md:mt-1 text-gray-500 border-b-2 pb-2 py-1 md:py-3'>
  <div className='flex items-center gap-4 px-2 font-semibold text-sm '>
    <AiOutlineLock className='md:text-xl text-lg  text-blue-700'/>
    <h1 className=''>Lock In </h1>
    
  </div>
  <p className='text-sm'>{overView ? overView.LockIn : ""}</p>
</div>
{/* Turnover */}
<div className='flex justify-between mx-1 md:mx-4 mt-1 md:mt-1 text-gray-500 border-b-2 pb-1 py-1 md:py-3'>
  <div className='flex items-center gap-4 px-2 font-semibold text-sm '>
    <GiCycle className='md:text-xl text-lg text-blue-700'/>
    <h1 className=''>TurnOver </h1>
    <AiOutlineInfoCircle className='text-gray-600 text-sm md:text-lg font-semibold'/>
  </div>
  <p className='text-sm'>{overView ? overView.TurnOver : ""} %</p>
</div>

        </CardContent>
      </Card>
      </div>
    </>
  )
}

export default FundOverView
