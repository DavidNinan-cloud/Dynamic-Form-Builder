import React, { useEffect, useState } from 'react'
import { createContext } from "react";
import {indexFundDetails,
        performanceDetails,
        performanceGraph,
        ifInvestedBarGraph,
        ifYouInvestedDetails,
        fundOverView,
        redeemedToday
        } from './db'



export const ElementsContext = createContext({});

export const ElementsContextProvider = ({ children}) => {
 // State Variable 
 const [data,setData] = React.useState() 
 return ( 
    <ElementsContext.Provider value={{ 
        indexFundDetails,
        performanceDetails,
        performanceGraph,
        ifInvestedBarGraph,
        ifYouInvestedDetails,
        fundOverView,
        redeemedToday
 }}> 
            {children} 
    </ElementsContext.Provider>
 );}