import React, { useContext, useEffect,useState } from 'react'
import { BiArrowBack } from "react-icons/bi";
import { BsCheckCircleFill,BsWhatsapp,BsTriangleFill } from "react-icons/bs";
import { HiOutlineStar } from "react-icons/hi";
import {Button} from '@mui/material'
import { BiRupee } from "react-icons/bi";
import { MdAutoGraph } from "react-icons/md";
import IfYouInvested from './IfYouInvested'
import RedeemedToday from './RedeemedToday'
import DashboardGraph from './DashboardGraph';
import { BsFillArrowUpCircleFill } from "react-icons/bs";
import { ElementsContext } from './DashboardContextApi';
import Footer from './Footer/Footer';
import AboutUs from '../AboutUs/AboutUs'







export default function Home() {

const {indexFundDetails}=useContext(ElementsContext)
const {performanceDetails}=useContext(ElementsContext)

const [indexFund,setIndexFund]=useState(null)
const [performanceDt,setPerformanceDt]=useState(null)

useEffect(()=>{
    setIndexFund(indexFundDetails)
    setPerformanceDt(performanceDetails)
},[indexFundDetails,performanceDetails])


  return (
    <>
    <div className="md:w-full min-h-screen overflow-hidden bg-[#164d78] "
     
// style={{background:'linear-gradient(to bottom, rgba(22,77,120,1) 0%,rgba(22,77,120,1) 1%,rgba(30,87,153,0.88) 63%,rgba(249,239,240,0.81) 100%)'}}
     >
      <div className='flex justify-between items-center  py-4 md:mx-8 mx-2 text-white'>
        <BiArrowBack className='text-2xl'/>
        <div className='flex items-center gap-3 md:gap-8 bg-opacity-40 border border-gray-600 shadow-lg rounded-full py-1 md:px-10 px-2'>
            <BsCheckCircleFill className='text-green-500 text-xl'/>
<h1>Zero Commission fund</h1>
        </div>
        <div className='flex items-center md:text-2xl text-lg gap-6'>
            <HiOutlineStar/>
            <BsWhatsapp/>
        </div>
    </div> 

    <div className='text-center md:text-2xl mx-8 text-white mt-5'>
        <span className='font-bold'>UTI Nifty 50 Index Fund-Growth Option-Direct</span>
        <br/>
        <div className='flex items-center justify-center text-sm gap-1 py-2 md:font-bold mt-1' >
        NAV <BiRupee/> {indexFund ? indexFund.Nav : "" } | 1D <BiRupee className=''/>{indexFund ? indexFund.D : ""}  <span className='flex items-center gap-1 px-2 text-green-400'><BsTriangleFill/> {indexFund ? indexFund.percentage :""}%</span>
        </div>
        
    </div> 

    <div className='flex justify-between md:mx-24 mx-3 font-medium text-gray-400 mt-7'>
        <p>
            Invested
            <span className='flex items-center text-white'><BiRupee className='md:text-lg'/>{performanceDt ? performanceDt.Invested : ""}</span>
        </p>
        <p>
            Current Value
            <span className='flex items-center text-white'><BiRupee className='md:text-lg'/>{performanceDt ? performanceDt.CurrentValue : ""}</span>
        </p>
        <p>
        Gain/XIRR% 
            <span className='flex items-center text-white'><BiRupee className='md:text-lg '/>{performanceDt ? performanceDt.Gain : ""} <span className='px-1 text-green-400'>
            {performanceDt ? performanceDt.XIRR : ""}%</span></span>
        </p>
    </div>
<div>
    <DashboardGraph />
</div>

<div  className='flex justify-center md:gap-24 gap-4  md:px-6 mt-4 '>
    {/* <div>
    <MdAutoGraph className=' rounded-full bg-blue-600 w-16 p-1 h-8 text-white '/>
    </div> */}
    <Button sx={{color:"white"}}>1M</Button>
    <Button sx={{color:"white"}}>3M</Button>
    <Button sx={{color:"white"}}>6M</Button>  
    <div className="hidden md:block gap-4">
    <Button sx={{color:"white"}} >1Y</Button>
    </div> 
    <div className=" hidden md:block gap-4">
    <Button sx={{color:"white"}} >3Y</Button>
    </div>
    
    <div className='rounded-full bg-gray-400 bg-opacity-40 '>
    <Button variant='' sx={{color:"white", }} className='rounded-full' >MAX</Button>
    </div>
   

</div>

<div className=' md:w-40 w-36 rounded-full bg-blue-600 flex justify-end my-5  align-center mr-5 drop-shadow-2xl  ml-auto pr-1 fixed bottom-4 right-0 z-50' 
>

<Button sx={{color:'white'}}  > < BsFillArrowUpCircleFill className="md:text-3xl text-lg mr-2 animate-bounce mt-1 " />  Invest More</Button>
</div>

    </div>

    {/* cards */}
    <div className='overflow-hidden'>
        <RedeemedToday/>
    {/* Line graph with Cards */}
        <IfYouInvested/>
    <AboutUs/>
        <Footer/>
    </div>
    </>
  )
}

