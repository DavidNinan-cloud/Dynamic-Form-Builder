import React from 'react'
import{Box,TextField,TextareaAutosize}  from '@mui/material';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';


const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };

function ContactUs() {
    
        const [open, setOpen] = React.useState(false);
        const handleOpen = () => setOpen(true);
        const handleClose = () => setOpen(false);
  return (
    <>
    {/* contact form */}
    <div className='flex justify-center  pb-2  text-black w-48 mx-auto overflow-hidden '>
      <Button onClick={handleOpen} sx={{background:'rgba(239, 239, 240)',border:'1px solid gray', color:'black',width:{md:'10rem',xs:'10rem'},height:{md:'40px'}}}
      variant="contained" >Contact Us</Button>
    <Modal
      open={open}
      onClose={handleClose} 
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
      // maxWidth='lg'
      className="overflow-hidden"
    >
      <Box sx={{...style,width:{xs:300,md:1000}}} className="overflow-hidden mr-8 ">
        <Typography id="modal-modal-title" variant="h6" component="h2" className='text-center text-3xl'>
        Contact Us
        </Typography>
        <Typography id="modal-modal-description" sx={{ mt: 2 }}>
        
          <div className='md:flex md:justify-between md:mx-3 w-full'>
          <TextField id="standard-basic" label="Full Name *"  variant="standard" className='w-60' />
        <TextField id="standard-basic" label="Email *"  variant="standard" />
        <TextField id="standard-basic" label="Company *"  variant="standard" />
          </div>
          
          <TextareaAutosize
          aria-label="empty textarea"
          placeholder="Your Message"
          style={{ width:{md:880} }  }
          className="md:mt-12 mt-5 border-b border-gray-500 md:mx-2 md:w-full w-56  "
          />
          <div className='mt-10 flex md:justify-end justify-center '>
          <Button variant="contained" size='large '>SEND</Button>
          </div>


        
      
        </Typography>
      </Box>
    </Modal>
</div>
    </>
  )
}

export default ContactUs
