import { Button, CardContent, Card } from "@mui/material";
import React from "react";
import ContactUs from "./ContactUs";

function AboutUs() {
  return (
    <>
      {/* company info */}
      <div className="overflow-hidden">
        <h1 className="text-xl shadow-lg font-bold px-6 md:py-3 py-3">
          About Us
        </h1>
        <div className="md:flex  w-80 md:w-auto">
          <div className=" absolute overflow-hidden ">
            <img
              src="https://cdn.pixabay.com/photo/2016/09/19/18/30/calculator-1680905_960_720.jpg"
              width={700}
              className="m-4 shadow-xl opacity-50 md:opacity-100  "
            />
          </div>
          <div className="relative z-40 md:z-0 md:left-1/2 top-20 left-32 md:top-0">
            <h1 className="font-semibold text-2xl md:text-black text-red-700  md:text-2xl md:mt-2   ">
              __Our Story
            </h1>
            <h1 className="font-semibold text-lg md:text-4xl md:mt-3 md:px-4 md:text-black text-red-700">
              Our team comes with the <br />
              experience and knowledge
            </h1>

            <div className="relative right-28 md:right-0 z-20">
              <Card
                sx={{
                  background: "rgba(239, 239, 240)",
                  marginY: "12px",
                  marginY: { md: "25px" },
                  marginLeft: { xs: "7px" },
                }}
                className=" md:w-full  md:h-20 h-20 mb-10  overflow-hidden "
              >
                <CardContent className="flex md:gap-3 gap-2 md:mx-5 my-1 md:text-lg text-sm ">
                  <Button
                    variant="contained"
                    sx={{
                      background: "white",
                      color: "black",
                      width: { md: "10rem", xs: "12rem" },
                      height: { md: "40px", xs: "50px" },
                      marginBottom: { xs: "px" },
                    }}
                  >
                    Who we are
                  </Button>
                  <Button
                    variant="contained"
                    sx={{
                      background: "white",
                      color: "black",
                      width: { md: "10rem", xs: "12rem" },
                      height: { md: "40px", xs: "50px" },
                      marginBottom: { xs: "px" },
                    }}
                  >
                    Our version
                  </Button>
                  <Button
                    variant="contained"
                    sx={{
                      background: "white",
                      color: "black",
                      width: { md: "10rem", xs: "12rem" },
                      height: { md: "40px", xs: "50px" },
                      marginBottom: { xs: "px" },
                    }}
                  >
                    Our History
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Profile */}
            <div className="md:w-96 pb-24 md:pb-0 md:mx-8 relative md:right-0 right-24  md:font-semibold md:mt-1  ">
              <p className="text-gray-500 text-sm md:text-lg leading-tight">
                We are the company for the handling of financial assets and
                other investments—not only buying and selling them.
                <br /> Management includes devising a short- or long-term
                strategy for acquiring and disposing of portfolio holdings. It
                can also include to find the profitable companies to invest in &
                stockmarket.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Card */}
      <div className="flex justify-center p-10 md:p-0 bg-[url(https://cdn.pixabay.com/photo/2020/08/09/14/25/business-5475658_960_720.jpg)] md:mt-10 ">
        <Card
          sx={{
            maxWidth: 800,
            marginTop: { md: "50px" },
            marginBottom: { md: "50px" },
            background: "rgba(149, 165, 166)",
          }}
        >
          <div className="  my-4 flex justify-center pb-5 md:p-10  ">
            <div className=" text-2xl md:text-5xl md:font-bold font-semibold md:py-7 md:mr-60 mr-40 absolute">
              <h1>
                Hi, <br /> I'm Alien
              </h1>
            </div>
            <div className=" text-sm md:text-xl md:font-bold font-semibold py-7 mt-10 md:mt-28 md:mr-20 ml-5">
              <h1 className="text-center">
                Investment Expert in investing <br />
                companies of stock Market
              </h1>
            </div>
            <div className=" text-sm md:text-xl py-7 mt-40 md:mt-48 px-7 text-gray-300 md:mr-60  w-96 md:w-auto absolute">
              <span className="text-sm md:text-lg ml-8 md:ml-0 ">
                This is a great space to write a long text{" "}
              </span>{" "}
              <br />{" "}
              <span className="text-sm md:text-lg ml-8 md:ml-0 mt-3">
                about your company and your services.
              </span>
              <br />
              <span className="hidden md:block">
                You can use this space to go into a <br /> little more detail
                about your company.
              </span>
              <Button sx={{ textDecoration: "underline" }}>Read More</Button>
            </div>
            <img
              src="https://cdn.pixabay.com/photo/2012/04/25/01/34/smiley-41627_960_720.png"
              width={300}
              className="shadow-2 rounded  p-3 w-40 md:w-60 flex justify-end"
            />
          </div>
        </Card>
      </div>

      {/* you will learn how to */}
      <div className="overflow-hidden">
        <h1 className="text-center my-5 text-lg md:text-3xl font-semibold">
          You Will Learn How To
        </h1>
        <div className="overflow-hidden">
          <div className="md:flex md:justify-center  md:gap-96 text-9xl font-extrabold mx-28  md:mx-0 my-5">
            <div>
              <h1 className=" text-red-200 md:my-0 opacity-50">01</h1>
              <h1 className="md:text-lg text-sm font-bold relative bottom-20 md:left-0 left-2 ">Use Social Media to<br/> increase conversions</h1>
            </div>

            <div>
              <h1 className="text-purple-200 md:my-0 opacity-50">02</h1>
              <h1 className="md:text-lg text-sm font-bold relative md:bottom-20 bottom-24 md:left-0 left-2 ">Improve your brand<br/> awareness using analytics</h1>
            </div>

            <div>
              <h1 className="text-green-200 md:my-0 opacity-50">03</h1>
              <h1 className="md:text-lg text-sm font-bold relative md:bottom-20 bottom-24 md:left-0 left-2 ">Design marketing  <br/>materials that drive  sales</h1>
            </div>
          </div>
        </div>
      </div>

      {/* About PopUp */}
      <div>
        <ContactUs className="overflow-hidden" />
      </div>
    </>
  );
}

export default AboutUs;
