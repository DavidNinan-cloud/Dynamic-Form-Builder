import React from 'react'
import { createContext } from "react";
import {performanceDetails } from '../Dashboard/db'
import {ChargesBreakdown,OverallData,OverAllDrawerYears} from './ClientData'
// import OverallTable from './OverallTable';



export const ElementsContext = createContext({});

export const ElementsContextProvider = ({ children}) => {
 // State Variable 
 const [data,setData] = React.useState() 
 return ( 
    <ElementsContext.Provider value={{ 
       ChargesBreakdown,
        performanceDetails,
        OverallData,
        OverAllDrawerYears
       
 }}> 
  {/* <OverallTable data={data}
      
      /> */}
            {children} 
    </ElementsContext.Provider>
 );}