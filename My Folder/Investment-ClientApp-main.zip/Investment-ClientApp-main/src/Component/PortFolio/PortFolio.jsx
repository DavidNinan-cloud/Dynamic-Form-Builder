import React from 'react'
import { ElementsContextProvider } from './PortFolioContextApi'
import ClientHoldings from './ClientHoldings'

export default function Dashboard() {
  return (
    <div>
        <ElementsContextProvider>
            <ClientHoldings/>
      </ElementsContextProvider>
    </div>
  )
}