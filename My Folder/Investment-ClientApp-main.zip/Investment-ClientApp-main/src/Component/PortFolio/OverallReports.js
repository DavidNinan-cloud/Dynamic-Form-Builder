import React, { useContext, useEffect,useState } from 'react'
import {Card} from '@mui/material'
import { ElementsContext } from './PortFolioContextApi';
import OverallDrawer from './Drawers/OverallDrawer'

function OverallReports() {

    const { OverAllDrawerYears}=useContext(ElementsContext)
const [years,setYears]=useState(null)

useEffect(()=>{
    setYears(OverAllDrawerYears)
},[OverAllDrawerYears])
  return (
    <>
    
      <Card sx={{ width:"30%", overflow: "hidden",marginY:"16px" }}>
<h1 className='text-lg font-semibold text-gray-600 text-center'> Reports & Presentation </h1>
<div>
    <div>
        {/* <h1>{years ? years.year1 : ""}</h1> */}
        <OverallDrawer/>
    </div>
    <div>
        {/* <h1>{years ? years.year2 : ""}</h1>
        <OverallDrawer/> */}
    </div>
</div>
 


      </Card>
    </>
  )
}

export default OverallReports
