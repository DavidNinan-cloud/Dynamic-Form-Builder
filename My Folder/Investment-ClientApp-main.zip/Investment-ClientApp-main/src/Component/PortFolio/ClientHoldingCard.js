import React, { useContext, useEffect,useState } from 'react'
import {Card,Button} from '@mui/material'
import { ElementsContext } from './PortFolioContextApi';
import { FiArrowRight } from "react-icons/fi";
import OverallBreakDownTabs from './OverallBreakDownTabs';




function ClientHoldingCard() {
    const {ChargesBreakdown}=useContext(ElementsContext)
const [breakdownCharges,setBreakdownCharges]=useState(null)

useEffect(()=>{
    setBreakdownCharges(ChargesBreakdown)
},[ChargesBreakdown])
  return (
    <>
      <Card className='md:mx-16 mx-3 mt-4 p-3'>
<h1 className='md:text-xl font-semibold md:font-bold text-gray-600 border-b pb-2 md:pb-2'>Client Holdings</h1>

<Card className='md:mx-16 my-5 hidden '>
<div className='flex justify-center gap-16 md:gap-36 mt-2 text-sm font-semibold md:text-lg text-gray-500'>
        <div >
            <h1>Realised P&L</h1>
            <p className='mx-4 md:mx-8 text-red-600'>{breakdownCharges ? breakdownCharges.Realised : ""}</p>
        </div>
        <div>
            <h1>Unrealised P&L</h1>
            <p className='mx-4 md:mx-8 text-green-600'>+{breakdownCharges ? breakdownCharges.Unrealised : ""}k</p>
        </div>
    </div>


    <div className='flex justify-between md:px-16 px-5 text-gray-400 mx-4 font-semibold text-sm leading-8 bg-gray-100 '>
              <p>STCG Tax</p>
              <p className='flex items-center'>{breakdownCharges ? breakdownCharges.ChargesTaxes : ""} </p>
            </div>
            <div className='flex justify-between md:px-16 px-5 text-gray-400 mx-4 font-semibold  text-sm leading-8 '>
              <p>STCG Tax</p>
              <p className='flex items-center'>{breakdownCharges ? breakdownCharges.CreditsDebits : ""} </p>
            </div>
            <div className='flex justify-between md:px-16 px-5 text-gray-400 mx-4 font-semibold  text-sm leading-8 bg-gray-100 mb-4 '>
              <p>LTCG Tax</p>
              <p className='flex items-center text-red-600'>{breakdownCharges ? breakdownCharges.NetRealised : ""} </p>
              </div>
              <div className=' text-blue-600 mx-3 mb-3'>
                <Button sx={{textTransform:"none",marginX:'6px'}}><p>View charges breakdown</p> <FiArrowRight className='mx-3'/> </Button>
                
              </div>
</Card>

{/* Client OverallBreakDownTabs */}
<OverallBreakDownTabs />
      </Card>
    </>
  )
}

export default ClientHoldingCard
