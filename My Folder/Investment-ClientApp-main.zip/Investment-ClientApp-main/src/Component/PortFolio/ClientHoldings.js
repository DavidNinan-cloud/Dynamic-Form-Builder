import React, { useContext, useEffect,useState } from 'react'
import { BiRupee } from "react-icons/bi";
import { ElementsContext } from './PortFolioContextApi';
import ClientHoldingCard from './ClientHoldingCard';



function ClientHoldings() {

    
const {performanceDetails}=useContext(ElementsContext)
const [performanceDt,setPerformanceDt]=useState(null)

useEffect(()=>{
    setPerformanceDt(performanceDetails)
},[performanceDetails])

  return (
    <>
      {/* PortFolio */}
      <div className='text-center mt-7 text-2xl font-bold text-gray-700'>
        <h1>PortFolio</h1>
      </div>
      <div className='flex justify-between md:mx-16 mx-3 font-medium text-sm md:text-lg text-gray-400 md:mt-7 mt-3 border rounded shadow-lg md:p-4 p-2'>
        <p>
            Invested
            <span className='flex items-center text-black'><BiRupee className='md:text-lg'/>{performanceDt ? performanceDt.Invested : ""}</span>
        </p>
        <p>
            Current Value
            <span className='flex items-center text-black'><BiRupee className='md:text-lg'/>{performanceDt ? performanceDt.CurrentValue : ""}</span>
        </p>
        <p>
        Gain/XIRR% 
            <span className='flex items-center text-black'><BiRupee className='md:text-lg '/>{performanceDt ? performanceDt.Gain : ""} <span className='px-1 text-green-400'>
            {performanceDt ? performanceDt.XIRR : ""}%</span></span>
        </p>
    </div>

    {/* Client Holding Card */}
    <ClientHoldingCard/>

    
    </>
  )
}

export default ClientHoldings
