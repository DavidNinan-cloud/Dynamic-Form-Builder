export const ChargesBreakdown={
    Realised:-1.8,
    Unrealised:10.86,
    ChargesTaxes:16.95,
    CreditsDebits:-69.05,
    NetRealised:-87.8
}
export  const OverallData={
    result:[
        {
          id:1,
          Units:23,
          AverageInvested:1000,
          CurrentValue:500,
          Gain:300,
          
         },
         {
             id:2,
             Units:40,
          AverageInvested:2000,
          CurrentValue:700,
          Gain:100,
            },
            
      ],
      
}

export const OverAllDrawerYears={
    year1:2021,
    year2:2022
}

