import {Box,Tabs,Tab} from '@mui/material'
import TabPanel from '@mui/lab'
import OverallTable from './OverallTable'
import React from 'react'
import OverallReports from './OverallReports'




function OverallBreakDownTabs() {

 

const [value,setValue]=React.useState(0)

const handleChange =(e,val)=>{
setValue(val)
}



  return (
    <>
      <Box sx={{ borderBottom: 1, borderColor: 'divider',marginX:'3rem' }}>
  <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
    <Tab label="Overall"  />
    <Tab label="Breakdown"  />
   
  </Tabs>
</Box>

<TabPanels value={value} index={0}>
  <div className='flex justify-center gap-8'>
    <OverallTable/>
    <OverallReports/>
  </div>
</TabPanels>
<TabPanels value={value} index={1}>
  Folios
</TabPanels>

    </>
  )
}

function TabPanels(props){
const {children,value,index}=props

    return(
        <>
        {
            value === index && 
            (
                <h1>{children}</h1>
            )
        }
        </>
        )
}


export default OverallBreakDownTabs