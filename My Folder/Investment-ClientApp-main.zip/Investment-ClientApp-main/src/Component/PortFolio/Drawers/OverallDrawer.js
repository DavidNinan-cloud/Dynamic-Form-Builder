import { Drawer, Typography,Box } from '@mui/material'
import React from 'react'

function OverallDrawer() {
  const [drawerOpen,setDrawerOpen]=React.useState(false)
  return (
    <>
      <Drawer anchor='top' open={drawerOpen}
      onClose={()=>setDrawerOpen(true)}
      >
<Box sx={{padding:"2px"}} role="Presentation">
<Typography variant="h6">
  2021
</Typography>
</Box>
      </Drawer>
    </>
  )
}

export default OverallDrawer

