import React from 'react'

export default function HealthPlan() {
  return (
    <div>HealthPlan</div>
  )
}
